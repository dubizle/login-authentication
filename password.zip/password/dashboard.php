<?php
session_start();

// ✅ If user not logged in, redirect to login
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$email = $_SESSION['user'];
$usersFile = __DIR__ . '/users.json';

// ✅ Load users
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];
$currentUser = null;

foreach ($users as $u) {
    if ($u['email'] === $email) {
        $currentUser = $u;
        break;
    }
}

// ✅ If user not found (shouldn't happen), redirect
if (!$currentUser) {
    echo "<p style='color:red;'>User not found. Please log in again.</p>";
    session_destroy();
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Dashboard</title>
<link rel="stylesheet" href="style/style.css">
<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #00c6ff, #0072ff);
    margin: 0;
    padding: 0;
}

.dashboard {
    max-width: 600px;
    margin: 60px auto;
    background: #fff;
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0px 6px 25px rgba(0,0,0,0.2);
    text-align: center;
}

h2 {
    color: #007bff;
    margin-bottom: 10px;
}

.user-info {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 20px;
    text-align: left;
}

.user-info p {
    margin: 8px 0;
    font-size: 16px;
}

.btn {
    display: block;
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: #007bff;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    text-decoration: none;
    text-align: center;
    margin-top: 15px;
    transition: 0.3s;
}

.btn:hover {
    background: #0056b3;
}

.logout {
    background: red;
}

.logout:hover {
    background: darkred;
}
</style>
</head>
<body>
<div class="dashboard">
    <h2>Welcome, <?= htmlspecialchars($currentUser['email']) ?></h2>
    <p>Manage your account and view your profile details below 👇</p>

    <div class="user-info">
        <p><strong>Email:</strong> <?= htmlspecialchars($currentUser['email']) ?></p>
        <p><strong>Account Created:</strong> <?= $currentUser['created_at'] ?? 'N/A' ?></p>
        <p><strong>Last Login:</strong> <?= date('Y-m-d H:i:s') ?></p>
    </div>

    <a href="edit_profile.php" class="btn">✏️ Edit Profile</a>
    <a href="change_password.php" class="btn">🔐 Change Password</a>
    <a href="logout.php" class="btn logout">🚪 Logout</a>
</div>
</body>
</html>