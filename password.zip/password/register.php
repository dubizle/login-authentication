<?php
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $users = load_users();

    if (find_user_by_email($email)) {
        flash_set('error', 'Email already exists.');
    } else {
        $users[] = ['email' => $email, 'password' => $password];
        save_users($users);
        flash_set('success', 'Registration successful. Please login.');
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style/style.css">
    <title>Register</title>
</head>
<body>
<h2>Register</h2>
<p style="color:red;"><?= flash_get('error') ?></p>
<form method="POST">
    <input type="email" name="email" placeholder="Email" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    <button type="submit">Register</button>
</form>
<p>Already have an account? <a href="index.php">Login</a></p>
</body>
</html>