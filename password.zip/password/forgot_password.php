<?php
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    if (find_user_by_email($email)) {
        $_SESSION['reset_email'] = $email;
        header("Location: reset_password.php");
        exit;
    } else {
        flash_set('error', 'Email not found.');
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
</head>
<link rel="stylesheet" href="style/style.css">
<body>
<h2>Forgot Password</h2>
<p style="color:red;"><?= flash_get('error') ?></p>

<form method="POST">
    <input type="email" name="email" placeholder="Enter your email" required><br><br>
    <button type="submit">Continue</button>
</form>
<p><a href="index.php">Back to Login</a></p>
</body>
</html>