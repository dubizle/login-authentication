<?php
session_start();

// ✅ Flash message helpers
function flash_set($key, $message) {
    $_SESSION['flash'][$key] = $message;
}
function flash_get($key) {
    if (isset($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

// ✅ Load users from JSON
function load_users() {
    $file = __DIR__ . '/../users.json';
    if (!file_exists($file)) {
        file_put_contents($file, json_encode([]));
    }
    $json = file_get_contents($file);
    return json_decode($json, true);
}

// ✅ Save users to JSON
function save_users($users) {
    $file = __DIR__ . '/../users.json';
    file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT));
}

// ✅ Find user by email
function find_user_by_email($email) {
    $users = load_users();
    foreach ($users as $u) {
        if ($u['email'] === $email) return $u;
    }
    return null;
}