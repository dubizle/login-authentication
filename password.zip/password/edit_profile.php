<?php
session_start();

// ✅ Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$email = $_SESSION['user'];
$usersFile = __DIR__ . '/users.json';

// ✅ Load users
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];
$currentUser = null;
$currentIndex = null;

foreach ($users as $index => $u) {
    if ($u['email'] === $email) {
        $currentUser = $u;
        $currentIndex = $index;
        break;
    }
}

// ✅ If user not found
if (!$currentUser) {
    echo "<p style='color:red;'>User not found. Please log in again.</p>";
    session_destroy();
    exit;
}

$message = "";

// ✅ Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newEmail = trim($_POST['email']);
    $fullName = trim($_POST['full_name']);

    if (!empty($newEmail)) {
        $users[$currentIndex]['email'] = $newEmail;
        $_SESSION['user'] = $newEmail;
        $message .= "✅ Email updated successfully.<br>";
    }

    if (!empty($fullName)) {
        $users[$currentIndex]['full_name'] = $fullName;
        $message .= "✅ Full name updated successfully.<br>";
    }

    // ✅ Save updates
    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
    $currentUser = $users[$currentIndex];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Profile</title>
<link rel="stylesheet" href="style/style.css">
<style>
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #00c6ff, #0072ff);
    margin: 0;
    padding: 0;
}

.container {
    max-width: 600px;
    margin: 60px auto;
    background: #fff;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0px 6px 25px rgba(0,0,0,0.2);
}

h2 {
    color: #007bff;
    text-align: center;
    margin-bottom: 20px;
}

form label {
    font-weight: bold;
    margin-top: 15px;
    display: block;
}

form input[type="email"],
form input[type="text"] {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    margin-bottom: 15px;
    font-size: 16px;
}

button {
    width: 100%;
    padding: 12px;
    background: #007bff;
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #0056b3;
}

.message {
    text-align: center;
    color: green;
    font-weight: bold;
    margin-bottom: 15px;
}

a.back {
    display: block;
    text-align: center;
    margin-top: 15px;
    color: #007bff;
    text-decoration: none;
    font-weight: bold;
}

a.back:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<div class="container">
    <h2>✏️ Edit Profile</h2>

    <?php if ($message): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>

    <form method="post">
        <label for="full_name">Full Name</label>
        <input type="text" name="full_name" id="full_name" placeholder="Enter your full name" value="<?= htmlspecialchars($currentUser['full_name'] ?? '') ?>">

        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" placeholder="Enter new email" value="<?= htmlspecialchars($currentUser['email']) ?>">

        <button type="submit">💾 Save Changes</button>
    </form>

    <a href="dashboard.php" class="back">⬅️ Back to Dashboard</a>
</div>
</body>
</html>