<?php
require_once __DIR__ . '/includes/functions.php';

if (!isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.php");
    exit;
}

$email = $_SESSION['reset_email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $users = load_users();

    foreach ($users as &$u) {
        if ($u['email'] === $email) {
            $u['password'] = $newPassword;
            save_users($users);
            unset($_SESSION['reset_email']);
            flash_set('success', 'Password reset successful. You can now login.');
            header("Location: index.php");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<link rel="stylesheet" href="style/style.css">
<body>
<h2>Reset Password</h2>
<form method="POST">
    <input type="password" name="password" placeholder="Enter new password" required><br><br>
    <button type="submit">Reset Password</button>
</form>
</body>
</html>