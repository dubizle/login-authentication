<?php
require_once __DIR__ . '/includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $user = find_user_by_email($email);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $email;
        header("Location: dashboard.php");
        exit;
    } else {
        flash_set('error', 'Invalid email or password.');
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style/style.css">
    <title>Login</title>
</head>
<body>
<h2>Login</h2>
<p style="color:green;"><?= flash_get('success') ?></p>
<p style="color:red;"><?= flash_get('error') ?></p>

<form method="POST">
    <input type="email" name="email" placeholder="Email" required><br><br>
    <input type="password" name="password" placeholder="Password" required><br><br>
    <button type="submit">Login</button>
</form>
<p><a href="forgot_password.php">Forgot Password?</a></p>
<p>New user? <a href="register.php">Register</a></p>
</body>
</html>