<?php
session_start();

$usersFile = __DIR__ . '/users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];
$email = $_SESSION['user'] ?? null;
$message = "";

if (!$email) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $oldPassword = trim($_POST['old_password']);
    $newPassword = trim($_POST['new_password']);
    $confirmPassword = trim($_POST['confirm_password']);

    if ($newPassword !== $confirmPassword) {
        $message = "❌ New passwords do not match.";
    } else {
        $found = false;

        // Loop through users and update the matching one
        foreach ($users as &$user) {
            if ($user['email'] === $email) {
                $found = true;

                if (!password_verify($oldPassword, $user['password'])) {
                    $message = "❌ Old password is incorrect.";
                } else {
                    $user['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
                    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
                    $message = "✅ Password updated successfully.";
                }
                break;
            }
        }

        if (!$found) {
            $message = "❌ User not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password</title>
<link rel="stylesheet" href="style/style.css">
<style>
body {
    background: linear-gradient(135deg, #00c6ff, #0072ff);
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    width: 400px;
    text-align: center;
}

h2 {
    color: #007bff;
}

input {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 16px;
}

button {
    width: 100%;
    padding: 12px;
    background: #007bff;
    color: #fff;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background: #0056b3;
}

.message {
    margin-bottom: 15px;
    font-weight: bold;
}
</style>
</head>
<body>

<div class="container">
    <h2>Change Password</h2>
    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post">
        <input type="password" name="old_password" placeholder="Enter old password" required>
        <input type="password" name="new_password" placeholder="Enter new password" required>
        <input type="password" name="confirm_password" placeholder="Confirm new password" required>
        <button type="submit">Update Password</button>
    </form>
    <a href="dashboard.php">⬅ Back to Dashboard</a>
</div>

</body>
</html>